## usage

Run frontend in development mode with _npm start_

Start server to port 3005 with _npm run server_

If you encounter trouble running npm install, remove package-lock.json and try again.